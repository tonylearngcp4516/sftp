echo "http://localhost:8000/pagerank/"
echo "http://localhost:8000/wordcount/"
python -m SimpleHTTPServer 8000
